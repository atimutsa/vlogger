<?
$MESS["CLO_STORAGE_GOOGLE_XML_PARSE_ERROR"] = "unrecognized service response (error ##errno#)";
$MESS["CLO_STORAGE_GOOGLE_XML_ERROR"] = "service error: #errmsg#";
$MESS["CLO_STORAGE_GOOGLE_EMPTY_ACCESS_KEY"] = "The access key is not specified.";
$MESS["CLO_STORAGE_GOOGLE_EMPTY_SECRET_KEY"] = "The secret key is not specified.";
$MESS["CLO_STORAGE_GOOGLE_EMPTY_PROJECT_ID"] = "The project ID is not specified.";
$MESS["CLO_STORAGE_GOOGLE_EDIT_PROJECT_ID"] = "Project ID";
$MESS["CLO_STORAGE_GOOGLE_EDIT_ACCESS_KEY"] = "Access Key";
$MESS["CLO_STORAGE_GOOGLE_EDIT_SECRET_KEY"] = "Secret Key";
$MESS["CLO_STORAGE_GOOGLE_EDIT_HELP"] = "Before you start using this service, you have to activate <a href=\"https://cloud.google.com/storage/docs/signup\">Google Storage for Developers</a>. Then, use <a href=\"https://code.google.com/apis/console#:storage\">API Google console</a> to activate Legacy Access and enable billing.";
?>
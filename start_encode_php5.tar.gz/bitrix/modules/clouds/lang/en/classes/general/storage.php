<?
$MESS["CLO_STORAGE_MENU"] = "Cloud Storage";
$MESS["CLO_STORAGE_TITLE"] = "View and manage files in cloud storages";
$MESS["CLO_STORAGE_UPLOAD_MENU"] = "Move to cloud storage";
$MESS["CLO_STORAGE_UPLOAD_CONF"] = "Are you sure you want to upload the file to cloud storage?";
$MESS["CLO_404_ON_MOVED_FILE"] = "Error 404 occurred while moving the file.";
?>
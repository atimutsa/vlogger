<?
$MESS["CLO_OPTIONS_LOG_404_ERRORS"] = "Log 404 errors for files in cloud storage";
?>
<?
$clouds_default_option = array(
	"log_404_errors" => "N",
	"delayed_resize" => "N",
);
?>
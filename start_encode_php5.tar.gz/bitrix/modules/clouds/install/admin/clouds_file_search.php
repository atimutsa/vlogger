<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/clouds/admin/clouds_file_search.php");
?>

<?
$arModuleVersion = array(
	"VERSION" => "15.5.1",
	"VERSION_DATE" => "2015-09-14 16:30:00"
);
?>
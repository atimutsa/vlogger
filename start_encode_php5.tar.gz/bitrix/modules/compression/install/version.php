<?
$arModuleVersion = array(
	"VERSION" => "14.0.0",
	"VERSION_DATE" => "2013-10-31 11:00:00"
);
?>
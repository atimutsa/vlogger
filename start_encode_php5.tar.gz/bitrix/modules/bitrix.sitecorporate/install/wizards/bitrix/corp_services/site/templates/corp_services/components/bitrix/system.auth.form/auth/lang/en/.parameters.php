<?
$MESS ['SAF_TP_PATH_TO_BLOG'] = "Blog Path";
$MESS ['SAF_TP_PATH_TO_NEW_BLOG'] = "New Blog Creation Page";
$MESS ['SAF_TP_BLOG_GROUP_ID'] = "Blog Groups";
$MESS ['SAF_TP_PATH_TO_SONET_MESSAGES'] = "Social Network Messages Page";
?>
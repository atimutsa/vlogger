<?
$aMenuLinks = Array(
	Array(
		"Bank Cards", 
		"cards.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Personal Loans", 
		"credit.php", 
		Array(), 
		Array(), 
		"" 
	)
);
?>
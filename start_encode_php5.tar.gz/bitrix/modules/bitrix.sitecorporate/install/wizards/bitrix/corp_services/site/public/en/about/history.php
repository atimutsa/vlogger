<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("History");
?>

	    <p>J&V Bank was founded in 1993.</p> 
	    <p>Since then there have been many mergers that have resulted in the bank's current structure.</p>
	    <p>We began our international expansion in 1998 by opening branches in Russia and Europe, and have built a reputation of servicing our customers wherever their business takes them.</p> 
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
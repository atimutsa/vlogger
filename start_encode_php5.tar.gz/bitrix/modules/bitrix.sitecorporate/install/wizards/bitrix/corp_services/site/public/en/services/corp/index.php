<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Corporate");
?>
<p>J&V is one of the leaders in the market for corporate clients. 
Comprehensive banking services based on maximizing competitive advantages and opportunities creates a sustainable financial platform for the development of business ventures and holdings in various industries. For more than 16 years, the Bank has been working for its clients as a model of reliability and professionalism. </p> 
<p>J&V offers the following services for corporate clients:</p>
<ul> 
    <li><a href="trade.php">Trade Services</a></li> 
    <li><a href="card.php">Card Solution</a></li> 
    <li><a href="merchant.php">Merchant Services</a></li> 
</ul> 	

<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
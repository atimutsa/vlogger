<?
$aMenuLinks = Array(
	Array(
		"About J&V", 
		"about/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"News", 
		"news/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Products & Services", 
		"services/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Contacts", 
		"contacts/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>
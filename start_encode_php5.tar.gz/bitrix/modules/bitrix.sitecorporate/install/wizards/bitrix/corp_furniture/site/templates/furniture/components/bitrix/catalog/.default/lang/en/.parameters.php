<?
$MESS["SHOW_PICTURE_DETAIL"] = "Show Image";
$MESS["SHOW_PARENT_NAME"] = "Show section title";
?>
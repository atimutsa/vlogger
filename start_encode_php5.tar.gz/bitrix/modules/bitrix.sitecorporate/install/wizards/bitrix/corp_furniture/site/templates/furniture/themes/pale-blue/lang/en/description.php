<?
$MESS["CFST_THEME_PALE_BLUE"] = "Turquoise";
?>
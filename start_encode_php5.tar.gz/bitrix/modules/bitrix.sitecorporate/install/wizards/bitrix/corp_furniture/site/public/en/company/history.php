<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Key Milestones");
?> 
<table cellspacing="10"> 
  <tbody> 
    <tr><td valign="top">2001</td><td>Furniture Company formed </td></tr>
   							 
    <tr><td valign="top">2002</td><td>Fitting out of XXX Hotel </td></tr>
   							 
    <tr><td valign="top">2004</td><td>Moved to a new 210,000 sq. ft. factory at Castlemilk, Glasgow</td></tr>
   							 
    <tr><td valign="top">2005</td><td>Expanded its business furniture line with innovative solutions</td></tr>
   							 
    <tr><td valign="top">2007</td><td>Entered the home entertainment furniture market</td></tr>
   							 
    <tr><td valign="top">2008</td><td>Launch of recycling aggregates </tr>
   							 
    <tr><td valign="top">2010</td><td>Fitting out XXX Liner</td></tr>
   </tbody>
 </table>
 <?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
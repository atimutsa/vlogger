<?
$MESS["T_NEWS_DETAIL_BACK"] = "All News";
$MESS["CATEGORIES"] = "Related articles:";
?>
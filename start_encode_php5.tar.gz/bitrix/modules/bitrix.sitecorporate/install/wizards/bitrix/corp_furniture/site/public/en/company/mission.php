<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Mission &amp; Vision");
?> 
 
<h3>Our Mission Statement</h3>
 							 
<p>Our mission is to be a leader in the contract furniture industry.<br />
We sincerely desire to provide a wide choice of quality furniture designs at the best possible prices with service that exceeds our customers expectations. 
</p>
 
<h3>Our Vision Statement</h3>
 							  						 						 
<p>We want to be the best furniture company.<br />
We are always looking to the future of work environments and how we can offer cutting-edge products with innovative design, function, and aesthetics that make the workplace and home more appealing.</p>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
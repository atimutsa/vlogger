<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?$arTemplate = Array("NAME" => GetMessage('CFST_THEME_PINK'));?>
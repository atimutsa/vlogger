<?
$MESS["NEWS_TYPE_NAME"] = "News";
$MESS["NEWS_ELEMENT_NAME"] = "News";
$MESS["NEWS_SECTION_NAME"] = "Sections";
$MESS["PRODUCTS_TYPE_NAME"] = "Products and services";
$MESS["PRODUCTS_ELEMENT_NAME"] = "Products and services";
$MESS["PRODUCTS_SECTION_NAME"] = "Sections";
$MESS["VACANCIES_TYPE_NAME"] = "Job";
$MESS["VACANCIES_ELEMENT_NAME"] = "Vacancies";
$MESS["VACANCIES_SECTION_NAME"] = "Categories";
?>
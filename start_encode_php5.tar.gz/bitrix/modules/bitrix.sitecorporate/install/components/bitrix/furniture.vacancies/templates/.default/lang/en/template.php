<?
$MESS["SUPPORT_FAQ_GO_UP"] = "Up";
$MESS["FAQ_DELETE_CONFIRM"] = "Are you sure you want to delete this \"#ELEMENT#\"?";
?>
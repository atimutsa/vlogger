<?
$MESS ['IBLOCK_TYPE_TIP'] = "Select here one of the existing information block types. Click <b><i>OK</i></b> to load information blocks of the selected type.";
$MESS ['IBLOCKS_TIP'] = "Select here one of the existing information blocks. You can select multiple items by holding Ctrl down.";
$MESS ['PARENT_SECTION_TIP'] = "Specified the ID os a section whose elements (photos) will be displayed. Leave this field empty to pick random photos from any section of the specified information block.";
$MESS ['DETAIL_URL_TIP'] = "Specify here the path to an information block element details page.";
$MESS ['CACHE_TYPE_TIP'] = "<i>Auto</i>: the cache is valid during the time predefined in the cache settings;<br /><i>Cache</i>: always cache for the period specified in the next field;<br /><i>Do not cahce</i>: no caching is performed.";
$MESS ['CACHE_TIME_TIP'] = "Specify here the period of time during which the cache is valid.";
?>
<?
$MESS ['IBLOCK_DETAIL_URL'] = "URL of the page with the detail contents";
$MESS ['IBLOCK_TYPE'] = "Type of information block";
$MESS ['IBLOCK_IBLOCK'] = "Information block";
$MESS ['IBLOCK_ANY'] = "(any)";
$MESS ['IBLOCK_SECTION_ID'] = "Section ID";
$MESS ['CP_BPR_CACHE_GROUPS'] = "Respect Access Permissions";
?>
<?
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Information blocks module is not installed";
?>
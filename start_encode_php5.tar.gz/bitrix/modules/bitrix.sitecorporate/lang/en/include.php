<?
$MESS["SCOM_BUTTON_NAME"] = "Site#BR#&nbsp;&nbsp;Wizard";
$MESS["SCOM_BUTTON_DESCRIPTION"] = "Run the site design and configuration wizard";
?>
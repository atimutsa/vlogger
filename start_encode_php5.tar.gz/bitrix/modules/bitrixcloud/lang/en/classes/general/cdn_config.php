<?
$MESS["BCL_CDN_CONFIG_XML_PARSE"] = "Error parsing XML config file (code: #CODE#).";
?>
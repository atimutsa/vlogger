<?
$MESS ['BCL_MON_WS_SERVER'] = "Error getting parameters from server (code: #STATUS#).";
?>
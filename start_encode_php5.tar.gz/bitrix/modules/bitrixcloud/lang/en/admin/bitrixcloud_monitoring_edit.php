<?
$MESS["BCL_MONITORING_DOMAIN"] = "Domain";
$MESS["BCL_MONITORING_EMAIL"] = "Send alerts to e-mail";
$MESS["BCL_MONITORING_ADD_BTN"] = "Add";
$MESS["BCL_MONITORING_TEST_LICENSE"] = "Watch Bitrix license expiration";
$MESS["BCL_MONITORING_LANGUAGE"] = "Alert language";
$MESS["BCL_MONITORING_TEST_SSL_CERT_VALIDITY"] = "Watch SSL certificate expiration";
$MESS["BCL_MONITORING_TEST_DOMAIN_REGISTRATION"] = "Watch domain expiration";
$MESS["BCL_MONITORING_TEST_HTTP_RESPONSE_TIME"] = "Watch website uptime";
$MESS["BCL_MONITORING_TITLE"] = "Cloud Inspector";
$MESS["BCL_MONITORING_TAB"] = "Cloud Inspector parameters";
$MESS["BCL_MONITORING_TAB_TITLE"] = "Configure Cloud Inspector parameters";
$MESS["BCL_MONITORING_IS_HTTPS"] = "Use HTTPS for monitoring";
?>
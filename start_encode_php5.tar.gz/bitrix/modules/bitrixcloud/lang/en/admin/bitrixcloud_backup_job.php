<?
$MESS["BCL_BACKUP_JOB_TITLE"] = "Backup schedule";
$MESS["BCL_BACKUP_JOB_URL"] = "Server";
$MESS["BCL_BACKUP_JOB_TIME"] = "Time (UTC)";
$MESS["BCL_BACKUP_JOB_WEEK_DAYS"] = "Days of week";
$MESS["BCL_BACKUP_JOB_STATUS"] = "Status";
$MESS["BCL_BACKUP_JOB_NEVER"] = "Never performed";
$MESS["BCL_BACKUP_JOB_DELETE"] = "Cancel";
$MESS["BCL_BACKUP_JOB_DELETE_CONF"] = "Do you want to cancel backup?";
$MESS["BCL_BACKUP_JOB_ADD"] = "Add";
$MESS["BCL_BACKUP_JOB_ADD_TAB"] = "New schedule";
$MESS["BCL_BACKUP_JOB_ADD_TAB_TITLE"] = "Backup parameters";
$MESS["BCL_BACKUP_JOB_CANCEL_BTN"] = "Cancel";
$MESS["BCL_BACKUP_JOB_SAVE_BTN"] = "Save";
$MESS["BCL_BACKUP_JOB_FINISH_TIME"] = "Last backup (UTC)";
?>
<?
$MESS["BCL_INSTALL"] = "Install Module";
?>
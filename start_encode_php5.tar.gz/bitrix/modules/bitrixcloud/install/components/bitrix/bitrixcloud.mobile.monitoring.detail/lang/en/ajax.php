<?
$MESS["BCLMMD_BC_NOT_INSTALLED"] = "The Bitrix Cloud module is not installed.";
$MESS["BCLMMD_ACCESS_DENIED"] = "Access denied";
?>
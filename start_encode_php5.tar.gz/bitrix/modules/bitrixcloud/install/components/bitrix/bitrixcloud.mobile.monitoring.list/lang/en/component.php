<?
$MESS["BCLMMSL_BC_NOT_INSTALLED"] = "The Bitrix Cloud module is not installed.";
$MESS["BCLMMSL_MA_NOT_INSTALLED"] = "The Mobile Builder module is not installed.";
$MESS["BCLMMSL_MONITORING_NO_DATA_AVAILABLE"] = "unavailable";
$MESS["BCLMMSL_MONITORING_MESS_ALERT1_WEEK"] = "Weekly loss";
$MESS["BCLMMSL_MONITORING_MESS_ALERT1_MONTH"] = "Monthly loss";
$MESS["BCLMMSL_MONITORING_MESS_ALERT1_QUARTER"] = "Quarterly loss";
$MESS["BCLMMSL_MONITORING_MESS_ALERT1_YEAR"] = "Yearly loss";
$MESS["BCLMMSL_MONITORING_NO_DATA"] = "no data yet";
$MESS["BCLMMSL_ACCESS_DENIED"] = "Access denied";
?>
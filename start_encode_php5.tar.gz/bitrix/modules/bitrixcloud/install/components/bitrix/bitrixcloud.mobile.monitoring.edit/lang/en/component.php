<?
$MESS["BCLMME_BC_NOT_INSTALLED"] = "The Bitrix Cloud module is not installed.";
$MESS["BCLMME_MA_NOT_INSTALLED"] = "The Mobile Builder module is not installed.";
$MESS["BCLMME_ACCESS_DENIED"] = "Access denied";
$MESS["BCLMME_NO_DATA"] = "No data.";
?>
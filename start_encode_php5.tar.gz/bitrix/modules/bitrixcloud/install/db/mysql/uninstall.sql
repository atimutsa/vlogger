DROP TABLE if exists b_bitrixcloud_option;

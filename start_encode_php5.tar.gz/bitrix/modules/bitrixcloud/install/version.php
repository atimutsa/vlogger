<?
$arModuleVersion = array(
	"VERSION" => "15.5.0",
	"VERSION_DATE" => "2015-05-26 13:30:00",
);
?>